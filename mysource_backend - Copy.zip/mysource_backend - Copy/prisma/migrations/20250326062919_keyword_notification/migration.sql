-- AlterTable
ALTER TABLE `user` ADD COLUMN `notificationKeywords` VARCHAR(191) NULL;
