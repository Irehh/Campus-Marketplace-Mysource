-- AlterTable
ALTER TABLE `user` ADD COLUMN `needsCampusSelection` BOOLEAN NOT NULL DEFAULT false;
